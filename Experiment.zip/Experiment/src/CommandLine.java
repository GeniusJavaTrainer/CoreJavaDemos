
public class CommandLine {

	public static void main(String[] args) {
		int number1 = Integer.parseInt(args[0]);
		int number2 = Integer.parseInt(args[1]);
		
		int answer = number1 + number2;
		
		System.out.println("Answer: " + answer);
	}
}
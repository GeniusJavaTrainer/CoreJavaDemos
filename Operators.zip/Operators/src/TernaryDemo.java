
public class TernaryDemo {

	public static void main(String[] args) {
		int quantity = 100;
		int required = 20;
		
		int whatIsMore = (quantity > required)?quantity:required;
		
		System.out.println(whatIsMore);
	}
}
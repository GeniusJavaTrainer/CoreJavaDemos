
public class BitwiseForCondition {

	public static void main(String[] args) {
		int a = 8 ;
		int b = 9 ;
		//b++;
		//int c = b++;
		if(a == 7 & b++ > 8){
			// b > 8 ; b = b + 1 ;
			System.out.println("Correct");
		}else{
			System.out.println("Incorrect");
		}
		
		System.out.println("b = " + b);
	}
}
import java.util.Scanner;

public class LogicalAndOperator {

	public static void main(String[] args) {
		int ageOfDriver = 0;
		int experience = 0;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter age of the driver: ");
		ageOfDriver = scInput.nextInt();
		
		System.out.print("Enter experience of the driver: ");
		experience = scInput.nextInt();
		
		if(ageOfDriver > 30 && experience > 5){
			System.out.println("Driver is selected.");
		}else{
			System.out.println("Driver is not selected.");
		}
		
		scInput.close();
	}
}
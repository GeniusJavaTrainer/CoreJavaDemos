import java.util.Scanner;

public class InputCircle {

	public static void main(String[] args) {
		Scanner scInput = new Scanner(System.in);
		double radius = 0.0;
		double area = 0.0;
		//final double PI = 3.14;
		
		System.out.print("Enter radius: ");
		radius = scInput.nextDouble();
		
		area = Math.PI * radius * radius ;
		
		System.out.println("Area of circle is: " + area);
		
		scInput.close();
	}
}

public class BitwiseAndOrExOr {

	public static void main(String[] args) {
		int a = 3;// 0 0 1 1
		int b = 2;// 0 0 1 0
		          // 0 0 1 0. Result of Bitwise AND
				  // 0 0 1 1. Result of Bitwise OR
				  // 0 0 0 1. Result of Bitwise Ex-OR
		int answer = a & b;
		System.out.println("AND answer: " + answer);
		
		answer = a | b ;
		System.out.println("OR answer: " + answer);
		
		answer = a ^ b ;
		System.out.println("Ex-OR answer: " + answer);
	}
}

public class TypeCast {

	public static void main(String[] args) {
		byte num = 40;
		int era = 60;
		float percent = 90.78f;
		
		System.out.println(num);
		System.out.println(era);
		
		era = num;
		System.out.println("Implicit type conversion:");
		System.out.println(num);
		System.out.println(era);
		
		num = 40;
		era = 60;
		
		num = (byte)era;
		System.out.println("Explicit type conversion:");
		System.out.println(num);
		System.out.println(era);
		
		num = 40;
		era = 60;
		
		num = (byte)(num + era);
		System.out.println("Explicit type conversion in arithmetic:");
		System.out.println(num);
		System.out.println(era);
		
		num = 40;
		era = 60;
		
		num += era;
		System.out.println("Implicit type conversion in arithmetic:");
		System.out.println(num);
		System.out.println(era);
		
		era = (int)percent;
		System.out.println("era = " + era);
		
	}
}

public class Modulo {

	public static void main(String[] args) {
		int totalMinutes = 123;
		int minutesInHour = 60;
		
		int hours = 0 ;
		int minutes = 0 ;
		
		hours = totalMinutes/minutesInHour;
		minutes = totalMinutes%minutesInHour;
		
		System.out.println(hours + " hours and " + minutes + " minutes.");
	}
}

public class ShiftOperators {

	public static void main(String[] args) {
		int x = 10;
		int y = 3;
		
		int z = x << y;
		// 0 0 0 0   1 0 1 0
		// 0 0 1 0   1 0 0 0
		// 10 * (2 raised to 3)
		System.out.println("Answer: " + z);
	}
}
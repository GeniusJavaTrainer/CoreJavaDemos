
public class ModuloDemo {

	public static void main(String[] args) {
		float qty = 56.78f;
		float demand = 2.56f;
		
		float remaining = qty % demand;
		
		System.out.println("Remaining of the quantity: " + remaining);
	}
}
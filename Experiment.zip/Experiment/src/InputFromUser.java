import java.util.Scanner;

public class InputFromUser {

	public static void main(String[] args) {
		int number1 = 0;
		int number2 = 0;
		
		int answer = 0;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter first number: ");
		number1 = scInput.nextInt();
		
		System.out.print("Enter second number: ");
		number2 = scInput.nextInt();
		
		answer = number1 + number2;
		
		System.out.println("Answer: " + answer);
		
		scInput.close();
	}
}